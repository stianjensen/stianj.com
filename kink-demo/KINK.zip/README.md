kink-demo
=========

KINK demo for BEKK robocup 2013.